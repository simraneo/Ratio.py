./ore-miner  mine --address J2RxTDZ29eLFfBGaCjq3x7rbrTQ7PZ9W328er7KwTuAV --threads 8 --invcode 888888
./ore-miner  claim --address J2RxTDZ29eLFfBGaCjq3x7rbrTQ7PZ9W328er7KwTuAV

pause

